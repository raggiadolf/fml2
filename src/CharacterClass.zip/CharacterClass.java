/**
 * Created by Ragnar on 1.2.2015.
 */
public enum CharacterClass {
    Digit, Letter, Other, Whitespace, EOF
}
